// Fill out your copyright notice in the Description page of Project Settings.


#include "FItems/FHealthItem.h"
#include "Character/PlayerCharacter.h"

void UFHealthItem::Use(class APlayerCharacter* Character) {
	//if (Character) {
	//	Character->health += HealAmount;
	//}
	UE_LOG(LogTemp, Warning, TEXT("Define Use function for health item, it does nothing rn"));
}

